"""
Security Scanner for Fabric Notebooks
Scans all code cells for embedded secrets, passwords, API keys, and credentials.
"""

import re
import json
from typing import List, Dict, Tuple

# Secret detection patterns
SECRET_PATTERNS = [
    # Generic password patterns
    (r'(?i)(password|passwd|pwd)\s*[=:]\s*["\']([^"\']{4,})["\']', 'Password'),
    (r'(?i)(password|passwd|pwd)\s*[=:]\s*([^\s]{8,})', 'Password'),
    
    # API Keys and Tokens
    (r'(?i)(api[_-]?key|apikey)\s*[=:]\s*["\']([^"\']{16,})["\']', 'API Key'),
    (r'(?i)(access[_-]?key|accesskey)\s*[=:]\s*["\']([^"\']{16,})["\']', 'Access Key'),
    (r'(?i)(secret[_-]?key|secretkey|client[_-]?secret)\s*[=:]\s*["\']([^"\']{16,})["\']', 'Secret Key'),
    (r'(?i)(auth[_-]?token|token|bearer)\s*[=:]\s*["\']([^"\']{16,})["\']', 'Auth Token'),
    
    # AWS Credentials
    (r'AKIA[0-9A-Z]{16}', 'AWS Access Key ID'),
    (r'(?i)(aws[_-]?secret[_-]?access[_-]?key)\s*[=:]\s*["\']([^"\']{40})["\']', 'AWS Secret Access Key'),
    
    # Azure
    (r'(?i)(azure[_-]?storage[_-]?account[_-]?key)\s*[=:]\s*["\']([^"\']{40,})["\']', 'Azure Storage Key'),
    (r'(?i)(DefaultEndpointsProtocol=https?;.*AccountKey=)([^;"\'\s]+)', 'Azure Connection String'),
    (r'\?sv=\d{4}-\d{2}-\d{2}&[^\s"\']+', 'Azure SAS Token'),
    
    # Private Keys
    (r'-----BEGIN (?:RSA |DSA |EC )?PRIVATE KEY-----', 'Private Key'),
    (r'-----BEGIN OPENSSH PRIVATE KEY-----', 'SSH Private Key'),
    
    # Database Connection Strings
    (r'(?i)(mongodb(\+srv)?://[^\s"\']+)', 'MongoDB Connection String'),
    (r'(?i)(Server=.*Password=.*)', 'SQL Connection String'),
    (r'(?i)(redis://:[^@\s"\']+@)', 'Redis Connection String'),
    (r'(?i)(Host=.*Password=.*)', 'PostgreSQL Connection String'),
    
    # Generic high-entropy strings that look like secrets
    (r'(?i)(secret|token|key|password|pwd|passwd)\s*[=:]\s*["\']([A-Za-z0-9+/]{32,}={0,2})["\']', 'Potential Secret (High Entropy)'),
    
    # GCP
    (r'(?i)(type.*private_key_id.*private_key)', 'GCP Service Account Key'),
    
    # Generic tokens
    (r'(?i)(gh[pousr]_[A-Za-z0-9]{36,})', 'GitHub Token'),
    (r'(?i)(glpat-[A-Za-z0-9\-_]{20,})', 'GitLab Token'),
    (r'xox[baprs]-[0-9a-zA-Z]{10,}', 'Slack Token'),
]


def get_notebook_cells() -> List[Dict]:
    """Extract all code cells from the current notebook."""
    try:
        import notebookutils
        
        # Get current notebook context
        context = notebookutils.runtime.context
        notebook_name = context.get("currentNotebookName", "Unknown")
        
        # Remove .ipynb extension if present (getDefinition expects artifact name without extension)
        if notebook_name.endswith('.ipynb'):
            notebook_name = notebook_name[:-6]
        
        print(f"📓 Scanning notebook: {notebook_name}")
        
        # Use notebookutils.notebook.getDefinition() to retrieve notebook content
        notebook_content = notebookutils.notebook.getDefinition(
            name=notebook_name,
            workspaceId="",  # Current workspace
            format="ipynb"
        )
        
        # Parse notebook JSON
        notebook_data = json.loads(notebook_content)
        cells = []
        
        # Extract code cells
        for idx, cell in enumerate(notebook_data.get('cells', []), start=1):
            cell_type = cell.get('cell_type', '')
            
            # Only process code cells
            if cell_type == 'code':
                # Get cell source (can be string or list of strings)
                source = cell.get('source', [])
                if isinstance(source, list):
                    code = ''.join(source)
                else:
                    code = source
                
                if code.strip():  # Skip empty cells
                    cells.append({
                        'cell_number': idx,
                        'code': code
                    })
        
        print(f"📊 Found {len(cells)} code cells in notebook")
        return cells
        
    except Exception as e:
        print(f"⚠️  Error extracting cells: {e}")
        import traceback
        traceback.print_exc()
        return []


def scan_code_for_secrets(code: str) -> List[Tuple[str, str, str]]:
    """Scan code for secret patterns. Returns list of (pattern_type, matched_value, line)."""
    findings = []
    lines = code.split('\n')
    
    for line_num, line in enumerate(lines, 1):
        # Skip comments
        if line.strip().startswith('#'):
            continue
        
        for pattern, secret_type in SECRET_PATTERNS:
            matches = re.finditer(pattern, line)
            for match in matches:
                # Extract the matched secret value
                matched_value = match.group(0)
                
                # Mask the secret for display
                if len(matched_value) > 10:
                    masked_value = matched_value[:10] + '...[REDACTED]'
                else:
                    masked_value = '...[REDACTED]'
                
                findings.append((secret_type, masked_value, f"Line {line_num}: {line.strip()[:60]}"))
    
    return findings


def scan_notebook() -> Dict:
    """Main scanning function."""
    print("=" * 70)
    print("🔒 SECURITY SCANNER - Detecting Embedded Secrets")
    print("=" * 70)
    print()
    
    cells = get_notebook_cells()
    
    if not cells:
        print("⚠️  No code cells found to scan.")
        print("    This may be because:")
        print("    - The notebook hasn't been executed yet")
        print("    - No cells contain code")
        print()
        return {'total_cells': 0, 'issues_found': 0}
    
    print(f"📊 Scanning {len(cells)} code cell(s)...\n")
    
    total_issues = 0
    cells_with_issues = []
    
    for cell in cells:
        cell_num = cell['cell_number']
        code = cell['code']
        
        findings = scan_code_for_secrets(code)
        
        if findings:
            total_issues += len(findings)
            cells_with_issues.append((cell_num, findings))
    
    # Report findings
    if total_issues == 0:
        print("✅ SUCCESS: No secrets detected in the scanned cells!")
        print()
    else:
        print(f"⚠️  ALERT: Found {total_issues} potential secret(s) in {len(cells_with_issues)} cell(s):\n")
        
        for cell_num, findings in cells_with_issues:
            print(f"📍 Cell #{cell_num}:")
            for secret_type, masked_value, context in findings:
                print(f"   • {secret_type}: {masked_value}")
                print(f"     Context: {context}")
            print()
        
        # Provide remediation guidance
        print("=" * 70)
        print("🔧 REMEDIATION RECOMMENDATIONS")
        print("=" * 70)
        print()
        print("Instead of hardcoding secrets, use secure alternatives:")
        print()
        print("1. Azure Key Vault:")
        print("   secret = notebookutils.credentials.getSecret('MyKeyVault', 'secret-name')")
        print()
        print("2. Fabric Variable Library:")
        print("   api_key = notebookutils.variable.get('api_key')")
        print()
        print("3. Environment Variables:")
        print("   import os")
        print("   password = os.getenv('DB_PASSWORD')")
        print()
        print("4. Fabric Connections:")
        print("   Use Fabric Connection artifacts for data source credentials")
        print()
    
    print("=" * 70)
    print("Scan complete.")
    print("=" * 70)
    
    return {
        'total_cells': len(cells),
        'cells_scanned': len(cells),
        'issues_found': total_issues,
        'cells_with_issues': len(cells_with_issues)
    }


# Run the scan
if __name__ == "__main__":
    results = scan_notebook()
