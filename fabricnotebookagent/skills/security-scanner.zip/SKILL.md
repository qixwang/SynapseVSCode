---
name: security-scanner
description: Scans notebook code cells for embedded passwords, secrets, API keys, tokens, and other sensitive credentials. Use when you need to audit code for security vulnerabilities, ensure no hardcoded secrets exist, or validate code before committing/publishing. Detects common patterns like passwords, API keys, connection strings, access tokens, private keys, and database credentials.
---

# Security Scanner

Scans all code cells in the current notebook to detect embedded passwords, secrets, API keys, and other sensitive information that should not be hardcoded.

## Quick Start

Run the security scanner script to analyze all code cells:

```python
%run -b ./builtin/skills/security-scanner/scripts/scan_secrets.py
```

The script will:
1. Extract all code cells from the notebook
2. Scan each cell for common secret patterns
3. Report any findings with cell numbers and matched patterns
4. Provide recommendations for remediation

## What Gets Detected

The scanner identifies common patterns including:
- **Passwords**: `password=`, `pwd=`, `passwd=`
- **API Keys**: `api_key=`, `apikey=`, `access_key=`
- **Tokens**: `token=`, `auth_token=`, `bearer`
- **Secrets**: `secret=`, `client_secret=`
- **Connection Strings**: SQL, MongoDB, Redis connection strings
- **Private Keys**: RSA, SSH, PEM formatted keys
- **AWS Credentials**: `aws_access_key_id`, `aws_secret_access_key`
- **Azure Keys**: `azure_storage_account_key`, SAS tokens
- **Generic Credentials**: High-entropy strings that look like credentials

## Best Practices

Instead of hardcoding secrets:
1. **Use Azure Key Vault** with `notebookutils.credentials.getSecret()`
2. **Use environment variables** loaded at runtime
3. **Use Fabric Connections** for data source credentials

Example secure pattern:
```python
# ❌ Bad - Hardcoded secret
api_key = "sk_live_51abc123xyz789"

# ✅ Good - Retrieved from Key Vault
api_key = notebookutils.credentials.getSecret("MyKeyVault", "api-key")
```

## Limitations

- May produce false positives for example code or test data
- Cannot detect obfuscated or base64-encoded secrets
- Does not scan external files or data sources
- Pattern-based detection only (not AI-powered)

## Running the Scanner

Execute in a notebook cell:
```python
%run -b ./builtin/skills/security-scanner/scripts/scan_secrets.py
```

Review the output and remediate any detected secrets before publishing or sharing your notebook.
